// const user = require('../models/userModel');

const getMessages = async (req, res) => {
  res.status(200).render('chat');
};

module.exports = {
  getMessages,
};
