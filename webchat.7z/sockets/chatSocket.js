const dayjs = require('dayjs');

module.exports = (io) => io.on('connection', (socket) => {
  // io.emit('connected', socket.id.substr(0, 16));
  socket.on('message', ({ chatMessage, nickname }) => {
    const timeStamp = dayjs().format('DD-MM-YYYY HH:mm:ss');
    io.emit('message', `${timeStamp} - ${nickname}: ${chatMessage}`);
  });
  // socket.on('disconnect', () => {
  //   socket.broadcast.emit('message', `${socket.io} se desconectou.`)
  // });
});
